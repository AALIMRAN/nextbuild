<?php
/*
Plugin Name: Nextbuild Core
Plugin URI: https://www.theimran.com/
Description: Most important plugin for your theme. you have to install this must.
Version: 1.0.0
Author: Abdullah Al Imran
Author URI: https://www.theimran.com/
Text Domain: nextbuild
*/


// add_filter('acf/settings/show_admin', '__return_false');
require_once('lib/advanced-custom-fields-pro-master/acf.php');
require_once('lib/nextbuild-acf-fields/acf-fields.php');
require_once('nextbuild.shortcode.php');
require_once('nextbuild.posttype.php');