<?php
/*
* Shortcode Fiels
*/
require_once('shortcode/call-to-action.php');
require_once('shortcode/section-title.php');
require_once('shortcode/project.php');
require_once('shortcode/contact-details.php');
require_once('shortcode/testimonial.php');
require_once('shortcode/pricing-table.php');
require_once('shortcode/workers.php');
require_once('shortcode/blog-post.php');
require_once('shortcode/offer.php');
require_once('shortcode/offer-carousel.php');
?>