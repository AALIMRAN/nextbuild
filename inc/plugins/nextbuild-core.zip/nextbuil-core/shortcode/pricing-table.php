<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_pricing_table( $atts, $content ) {
	$atts = shortcode_atts( array(
		'type' => '',
		'price'	=>	'',
		'payment_type'	=>	'',
		'price_list'	=>	'',
		'button_text'	=>	'',
		'button_link'	=>	'',
	), $atts, 'nextbuild-pricing-table' );
	extract($atts);
	ob_start();?>

		<div class="plan">
		    <div class="head">
		        <h2><?php echo esc_html($type); ?></h2>
		    </div>
		    <div class="price">
		        <h3><span class="symbol">$</span><?php echo esc_html($price); ?></h3>
		        <h4><?php echo esc_html($payment_type); ?></h4>
		    </div>
		    <ul class="item-list">
		       <?php echo wp_kses_post($price_list); ?>
		    </ul>
		    <a href="<?php echo esc_url($button_link); ?>" class="btn btn-primary"><?php echo esc_html($button_text); ?></a>
		</div>

	<?php return ob_get_clean();

	// do shortcode actions here
}
add_shortcode( 'nextbuild-pricing-table', 'nextbuild_pricing_table' );


add_action('init', 'nextbuild_pricing_table_kc');

function nextbuild_pricing_table_kc(){

	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-pricing-table'	=>	array(
					'name'	=>	__( 'Pricing Table', 'nextbuild' ),
					'category'	=>	'NextBuild',
					'icon'		=>	'dashicons dashicons-editor-paste-text',
					'params'	=>	array(
						array(
							'name'	=>	__( 'type', 'nextbuild' ),
							'label'	=>	__( 'Pricing Type', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'price', 'nextbuild' ),
							'label'	=>	__( 'Price', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'payment_type', 'nextbuild' ),
							'label'	=>	__( 'Payment Type', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'price_list', 'nextbuild' ),
							'label'	=>	__( 'Prcing List', 'nextbuild' ),
							'type'	=>	'textarea',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'button_text', 'nextbuild' ),
							'label'	=>	__( 'Button Text', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'button_link', 'nextbuild' ),
							'label'	=>	__( 'Button Link', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
					)
				),
			)
		);
	}
}