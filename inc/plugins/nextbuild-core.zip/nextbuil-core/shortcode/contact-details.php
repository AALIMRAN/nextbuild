<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *	Name: Phone Number
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_contact_details( $atts, $content ) {
	$atts = shortcode_atts( array(
		'number' => '',
		'details' => '',
	), $atts, 'nextbuild-contact-details' );
	extract($atts);
ob_start();?>

<div class="contact-details text-center">
    <h1><?php echo esc_html($number); ?></h1>
    <?php echo wp_kses_post( $details ); ?>
</div>

<?php return ob_get_clean();

}
add_shortcode( 'nextbuild-contact-details', 'nextbuild_contact_details' );

add_action('init', 'nextbuild_contact_details_kc');


function nextbuild_contact_details_kc(){
	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-contact-details'	=>	array(
					'name'	=>	__( 'Contact Details', 'nextbuild' ),
					'category'	=>	'NextBuild',
					'icon'		=>	'dashicons dashicons-admin-home',
					'params'	=>	array(
						array(
							'name'	=>	__( 'number', 'nextbuild' ),
							'type'	=>	'text',
							'label'	=>	__( 'Phone Number' , 'nextbuild' ),
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'details', 'nextbuild' ),
							'type'	=>	'textarea',
							'label'	=>	__( 'Phone Number' , 'nextbuild' ),
							'description'	=>	__( 'Type Your Contact Details As HTML format under h2 tag.', 'nextbuild' ),
							'admin_label'	=>	true,
						),
					)
				),
			)
		);
	}
}

