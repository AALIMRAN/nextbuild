<?php

/**
 * Name: Call to action Shortcode
 *
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_call_to_action_shortcode( $atts, $content ) {
	$atts = shortcode_atts( array(
		'title' => '',
		'subtitle' => '',
		'buttons'	=>	'',
	), $atts, 'nextbuild-call-to-action' );
	extract($atts);
	ob_start(); ?>

    <div class="welcomemessage text-center">
        <h2><?php echo esc_html( $title ); ?></h2>
        <p class="lead"><?php echo base64_decode( $subtitle ); ?></p>
        <?php
        foreach ($buttons as $button) :
        	$button_styles = ($button->button_style == 'button_primary' ? ' btn-primary' : ' btn-dark');
        	echo '<a class="btn'.$button_styles.' btn-lg" href="'.esc_url($button->button_link).'">'.$button->button_text.'</a> ';
        endforeach;
         ?>
    </div><!-- end messagebox -->

	<?php return ob_get_clean();
}
add_shortcode( 'nextbuild-call-to-action', 'nextbuild_call_to_action_shortcode' );

/**
 * Call to action Kingcomposer Addons
 */

add_action('init', 'nextbuild_call_to_action_shortcode_kc');
function nextbuild_call_to_action_shortcode_kc(){
	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-call-to-action'	=>	array(
					'name'	=>	__('Call To Action', 'nexbuild'),
					'description'	=>	__( 'Display Call to Action Addons', 'nextbuild' ),
					'category'		=>	'NextBuild',
					'icon'			=>	'dashicons dashicons-phone',
					'params'		=>	array(
						array(
							'name'	=>	__( 'title', 'nextbuild' ),
							'admin_label'	=>	true,
							'label'	=>	__( 'Title', 'nextbuild' ),
							'type'	=>	'text',
						),
						array(
							'name'	=>	__( 'Subtitle', 'nextbuild' ),
							'admin_label'	=>	true,
							'label'	=>	__( 'Subtitle', 'nextbuild' ),
							'type'	=>	'textarea',
						),
						array(
							'name'	=>	__( 'buttons', 'nextbuild' ),
							'admin_label'	=>	false,
							'label'	=>	__( 'Subtitle', 'nextbuild' ),
							'type'	=>	'group',

							'params'	=>	array(
								array(
									'name'	=>	__( 'button_text', 'nextbuild' ),
									'label'	=>	__( 'Button Text', 'nextbuild' ),
									'type'	=>	'text',
								),
								array(
									'name'	=>	__( 'button_link', 'nextbuild' ),
									'label'	=>	__( 'Button Link', 'nextbuild' ),
									'admin_label'	=>	true,
									'type'	=>	'text',
								),
								array(
									'name'	=>	__( 'button_style', 'nextbuild' ),
									'label'	=>	__( 'Button Style', 'nextbuild' ),
									'type'	=>	'radio',
									'options'	=>	array(
										'button_primary'	=>	__( 'Button Primary','nextbuild' ),
										'button_dark'	=>	__( 'Button Dark', 'nextbuild' )
									),
								),
							),
						),
					)
				),
			)
		);
	}
}