<?php

 /**
  * Returns the parsed shortcode.
  * Name : Project Shortcode
  * @param array   {
  *     Attributes of the shortcode.
  *
  *     @type string $id ID of...
  * }
  * @param string  Shortcode content.
  *
  * @return string HTML content to display the shortcode.
  */
 function nextbuild_project_shortcode( $atts, $content ) {
 	$atts = shortcode_atts( array(
 		'post_per_pages' => '',
    'align'   =>  '',
 	), $atts, 'nextbuild-project' );
extract($atts);
	ob_start();?>
        <div class="text-<?php echo esc_attr($align);?> clearfix">
            <nav class="portfolio-filter">
                <ul>
                    <li><a href="#" data-filter="*"><i class="fa fa-filter"></i> All Projects</a></li>
		<?php $categories = get_terms( 'project-taxonomy');
			foreach ($categories as $category): ?>
                    <li><a href="#" data-filter=".<?php echo esc_attr($category->slug); ?>"><?php echo esc_html($category->name); ?></a></li>
			<?php endforeach; ?>
                </ul>
            </nav>
        </div><!-- end text-center -->
        <div class="portfolio">
	<?php
	$projects = new WP_Query(array(
		'post_type'	=>	'nextbuild-project',
		'posts_per_page'	=>	$post_per_pages
	));
	while ($projects->have_posts()) : $projects->the_post();
		$imagefield = get_field('image_size');
		$imagefieldH = get_field('height_size');
		$imagesize = ($imagefield == true ? ' item-w2' : ' item-w1');
		$imagesizeH = ($imagefieldH == true ? ' item-h2' : ' item-h1');
		?>
        <div class="pitem entry<?php echo esc_attr($imagesize); ?><?php echo esc_attr($imagesizeH);?> <?php $categories = get_the_terms(get_the_ID(), 'nextbuild-project-taxonomy'); if($categories != false){foreach ($categories as $category){echo ' '. esc_attr($category->slug); }} ?>">
        	<?php
        	$imageid = get_field('project_image');
			$projectimg = wp_get_attachment_url( $imageid );
        	?>
            <img src="<?php echo esc_url($projectimg); ?>" alt="" class="img-responsive">
            <div class="magnifier">
                <div class="buttons">
                    <a data-rel="prettyPhoto" href="<?php echo esc_url($projectimg); ?>" class="st" rel="bookmark"><span class="fa fa-search"></span></a>
                    <a class="st" rel="bookmark" href="<?php the_permalink(); ?>"><span class="fa fa-link"></span></a>
                </div>
            </div><!-- end magnifier -->
        </div>
	<?php endwhile; ?>

        </div><!-- end row -->
	<?php return ob_get_clean();

 }
 add_shortcode( 'nextbuild-project', 'nextbuild_project_shortcode' );


 /**
  * Project Addons for kingcomposer
  */


add_action('init', 'nextbuild_project_shortcode_kc');

function nextbuild_project_shortcode_kc(){

if (function_exists('kc_add_map')) {
	kc_add_map(
		array(
			'nextbuild-project'	=>	array(
 				'name'		=>	__( 'Filterable Project', 'nextbuild' ),
 				'category'	=>	'NextBuild',
 				'icon'		=>	'dashicons dashicons-images-alt2',
 				'params'	=>	array(
          array(
            'name'      =>  __( 'post_per_pages', 'nextbuild' ),
            'label'     =>  __( 'Posts Per Page', 'nextbuild' ),
            'type'      =>  'text',
            'admin_label' =>  true
          ),
 					array(
 						'name'			=>	__( 'align', 'nextbuild' ),
 						'label'			=>	__( 'Menu Alignment', 'nextbuild' ),
 						'type'			=>	'select',
 						'admin_label'	=>	true,
            'options'   =>  array(
              'left'    =>  __( 'left Align', 'nextbuild' ),
              'center'  =>  __( 'Center Align', 'nextbuild' ),
              'right'   =>  __( 'Right Align', 'nextbuild' )
            ),
 					),
 				)
 			),
		)
	);
}

}