<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_workers( $atts = array(), $content = '' ) {
	$atts = shortcode_atts( array(
		'worker_image' => '',
		'worker_name'	=>	'',
		'worker_detail'	=>	'',
		'worker_social'	=>	'',
	), $atts, 'nextbuild-workers' );
	extract($atts);
ob_start();?>

<div class="team-member-2">
    <div class="entry text-center">

	<?php echo wp_get_attachment_image($worker_image, 'nextbuild-workers-img', '', array('class' =>	'img-responsive')); ?>
        <div class="magnifier">
            <div class="buttons">
            <?php
            	foreach ($worker_social as $worker_link) : ?>
                <a class="st" rel="bookmark" href="<?php echo esc_url($worker_link->social_link); ?>"><span class="<?php echo esc_attr($worker_link->social_icon); ?>"></span></a>
            <?php endforeach; ?>
            </div>
            <h4><?php echo esc_html($worker_name); ?></h4>
            <p><?php echo wp_kses_post($worker_detail); ?></p>
        </div><!-- end magnifier -->
    </div><!-- end entry -->
</div><!-- end team-member -->

<?php return ob_get_clean();

}
add_shortcode( 'nextbuild-workers', 'nextbuild_workers' );

add_action('init', 'nextbuild_workers_kc');

function nextbuild_workers_kc(){

	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-workers'	=>	array(
					'name'	=>	__( 'Workers', 'nextbuild' ),
					'icon'	=>	'dashicons dashicons-universal-access-alt',
					'category'	=>	'NextBuild',
					'params'	=>	array(
						array(
							'name'	=>	__( 'worker_image', 'nextbuild' ),
							'lable'	=>	__( 'Workers Image', 'nextbuild' ),
							'type'	=>	'attach_image',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'worker_name', 'nextbuild' ),
							'lable'	=>	__( 'Workers Name', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'worker_detail', 'nextbuild' ),
							'lable'	=>	__( 'Workers Detaisl', 'nextbuild' ),
							'type'	=>	'textarea',
							'admin_label'	=>	true,
						),
						array(
							'name'	=>	__( 'worker_social', 'nextbuild' ),
							'lable'	=>	__( 'Workers Social Link', 'nextbuild' ),
							'type'	=>	'group',
							'params'	=>	array(
								array(
									'name'	=>	__( 'social_icon', 'nextbuild' ),
									'type'	=>	'icon_picker',
									'label'	=>	__( 'Choose Icon', 'nextbuild' ),
								),
								array(
									'name'	=>	__( 'social_link', 'nextbuild' ),
									'type'	=>	'text',
									'label'	=>	__( 'Input Link', 'nextbuild' ),
								),
							)
						),
					)
				),
			)
		);
	}
}

