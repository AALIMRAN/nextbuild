<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_section_title( $atts, $content) {
	$atts = shortcode_atts( array(
		'title' => '',
		'desc'	=>	'',
		'align'	=>	'',
	), $atts, 'nextbuild-section-title' );
	extract($atts);
	ob_start();?>

	<div class="general-title text-<?php echo esc_attr($align);?>">
        <h4><?php echo esc_html( $title ); ?></h4>
        <hr>
        <p class="lead"><?php echo wp_kses_post( $desc ); ?></p>
    </div><!-- end general title -->

	<?php return ob_get_clean();
}
add_shortcode( 'nextbuild-section-title', 'nextbuild_section_title' );

add_action('init', 'nextbuild_section_title_kc');

function nextbuild_section_title_kc(){
	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-section-title'	=>	array(
					'name'	=>	__( 'Section Title', 'nextbuild' ),
					'description'	=>	__( 'Display Section Title', 'nextbuild' ),
					'category'		=>	'NextBuild',
					'icon'	=>	'dashicons dashicons-editor-underline',
					'params'	=>	array(
						array(
							'name'	=>	__( 'title', 'nextbuild' ),
							'label'	=>	__( 'Title', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true
						),
						array(
							'name'	=>	__( 'desc', 'nextbuild' ),
							'label'	=>	__( 'Description', 'nextbuild' ),
							'type'	=>	'textarea',
							'admin_label'	=>	true
						),
						array(
							'name'	=>	__( 'align', 'nextbuild' ),
							'label'	=>	__( 'Title Alignment', 'nextbuild' ),
							'type'	=>	'select',
							'admin_label'	=>	true,
							'options'	=>	array(
								'center'	=>	__( 'Center Align', 'nextbuild' ),
								'left'		=>	__( 'Left Align', 'nextbuild' ),
								'right'		=>	__( 'Right Align', 'nextbuild' )
							),
						),
					)
				),
			)
		);
	}
}