<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_what_we_offer( $atts, $content) {
	$atts = shortcode_atts( array(
		'image' => '',
		'title'	=>	'',
		'desc'	=>	'',
		'align'	=>	''
	), $atts, 'nextbuild-offer' );
	extract($atts);
 	ob_start();?>
 	<div class="text-<?php echo esc_attr($align);?>">
		<div class="why-us">
			<?php echo wp_get_attachment_image( $image, 'nextbuild-offer-img'); ?>
	        <strong><?php echo esc_html( $title ); ?></strong>
	        <p><?php echo esc_html($desc); ?></p>
		</div>
	</div>
 	<?php return ob_get_clean();
}
add_shortcode( 'nextbuild-offer', 'nextbuild_what_we_offer' );

add_action( 'init', 'nextbuild_what_we_offer_kc' );

function nextbuild_what_we_offer_kc(){
	if (function_exists('kc_add_map')) {
		kc_add_map(array(
			'nextbuild-offer'	=>	array(
				'name'	=>	__( 'What We Offer', 'nextbuild' ),
				'icon'	=>	'dashicons dashicons-welcome-view-site',
				'category'	=>	'NextBuild',
				'params'	=>	array(
					array(
						'name'	=>	__( 'image', 'nextbuild' ),
						'label'	=>	__( 'Image', 'nextbuild' ),
						'type'	=>	'attach_image',
						'admin_label'	=>	true,
					),
					array(
						'name'	=>	__( 'title', 'nextbuild' ),
						'label'	=>	__( 'Title', 'nextbuild' ),
						'type'	=>	'text',
						'admin_label'	=>	true,
					),
					array(
						'name'	=>	__( 'desc', 'nextbuild' ),
						'label'	=>	__( 'Description', 'nextbuild' ),
						'type'	=>	'textarea',
						'admin_label'	=>	true,
					),
					array(
						'name'	=>	__( 'align', 'nextbuild' ),
						'label'	=>	__( 'Alignment', 'nextbuild' ),
						'type'	=>	'select',
						'admin_label'	=>	true,
						'options'   =>  array(
			              'left'    =>  __( 'left Align', 'nextbuild' ),
			              'center'  =>  __( 'Center Align', 'nextbuild' ),
			              'right'   =>  __( 'Right Align', 'nextbuild' )
			            ),
					),
				)
			)
		));
	}
}