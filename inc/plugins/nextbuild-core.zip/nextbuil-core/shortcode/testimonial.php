<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_testimonial_shortcode( $atts, $content) {
	$atts = shortcode_atts( array(
		'testimonials' => '',
	), $atts, 'nextbuild-testimonial' );
	extract($atts);
	ob_start();?>
	<section class="section next-testimonials">
		<div id="demo2" class="cssui-slider cssui-slider_mod--animation-3dscale">
			<input id="cssui-slider-control-label4" type="radio" class="cssui-slider__switch" name="cssui-slider-control2" checked>
			<label for="cssui-slider-control-label4" class="cssui-slider__control">open first slide</label>
			<input id="cssui-slider-control-label5" type="radio" class="cssui-slider__switch" name="cssui-slider-control2">
			<label for="cssui-slider-control-label5" class="cssui-slider__control">open second slide</label>
			<input id="cssui-slider-control-label6" type="radio" class="cssui-slider__switch" name="cssui-slider-control2">
			<label for="cssui-slider-control-label6" class="cssui-slider__control">open third slide</label>
			<div class="cssui-slider__slides">
			<?php foreach ($testimonials as $testimonial) : ?>
				<div class="cssui-slider__slide">
					<div class="cssui-slider__content">
						<div class="welcome">
							<?php $tesitmonialimage = $testimonial->testimonial_image;
							echo wp_get_attachment_image( $tesitmonialimage, 'nextbuild-testimonail-img', '', array('class'	=>	'avatar'))
							?>
							<div class="welcome__column">
								<h2 class="welcome__msg">
									<?php echo $testimonial->testimonial_title; ?>
								</h2>
								<p><?php echo $testimonial->testimonial_comments; ?></p>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php return ob_get_clean();

}
add_shortcode( 'nextbuild-testimonial', 'nextbuild_testimonial_shortcode' );

add_action('init', 'nextbuild_testimonial_shortcode_kc');

function nextbuild_testimonial_shortcode_kc(){

	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-testimonial'	=>	array(
					'name'	=>	__( 'Testimonial', 'nextbuild' ),
					'category'	=>	'NextBuild',
					'icon'		=> 	'dashicons dashicons-format-chat',
					'params'	=>	array(
						array(
							'name'	=>	__( 'testimonials', 'nextbuild' ),
							'label'	=>	__( 'Testimonial', 'nextbuild' ),
							'type'	=>	'group',
							'params'	=>	array(
								array(
									'name'	=>	__( 'testimonial_image', 'nextbuild' ),
									'label'	=>	__( 'Testimonial Image', 'nextbuild' ),
									'type'	=>	'attach_image',
									'admin_label'	=>	true,
								),
								array(
									'name'	=>	__( 'testimonial_title', 'nextbuild' ),
									'label'	=>	__( 'Title', 'nextbuild' ),
									'type'	=>	'text',
									'admin_label'	=>	true,
								),
								array(
									'name'	=>	__( 'testimonial_comments', 'nextbuild' ),
									'label'	=>	__( 'Comments', 'nextbuild' ),
									'type'	=>	'textarea',
									'admin_label'	=>	true,
								),
							)
						),
					)

				),
			)
		);
	}

}