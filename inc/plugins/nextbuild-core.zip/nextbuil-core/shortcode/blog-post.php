<?php
/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_blog_post( $atts, $content) {
	$atts = shortcode_atts( array(
		'post_per_page' => '',
	), $atts, 'nextbuild-blog-post' );
	extract($atts);
	ob_start();
	global $post;
	$blogpost = new WP_Query(array(
		'post_type'	=>	'post',
		'posts_per_page'	=>	$post_per_page,
	)); ?>
<div class="row module-wrapper blog-widget text-center">
	<?php while ($blogpost->have_posts()) : $blogpost->the_post();?>

                    <div class="col-md-4 col-sm-6">
			<div class="blog-wrapper blogshortcode">
				<?php if (has_post_thumbnail()): ?>
			    <div class="blog-image">
			        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('nextbuild-post-thumbnail', array('class' => 'img-responsive')); ?></a>
			    </div><!-- end image -->
				<?php endif;?>
			    <div class="blog-title">
			        <?php $categories = get_the_terms($post->ID, 'category');
			            foreach ($categories as $category) { ?>
			                    <a class="category_title" href="<?php echo esc_url(get_category_link($category->term_id)); ?>" title=""><?php echo esc_html($category->name); ?></a>
			            <?php } ?>
			        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			        <div class="post-meta">
		                <span>
		                    <i class="fa fa-user"></i>
		                    <?php nextbuild_posted_by(); ?>
		                </span>
		                <span>
		                    <i class="fa fa-tag"></i>
		                    <?php
		                    foreach ($categories as $category) { ?>
		                    <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>" title=""><?php echo esc_html($category->name); ?></a>
		                    <?php } ?>
		                </span>
		                <span>
		                    <i class="fa fa-comments"></i>
		                    <?php comments_popup_link(esc_html__('No Comment Yet', 'nextbuild'), esc_html__('One Comment', 'nextbuild'), esc_html__('% Comments', 'nextbuild')); ?>
		                </span>
		            </div>
			        <?php the_excerpt(); ?>
			        <a href="<?php the_permalink(); ?>" class="btn btn-primary btn-block"><?php esc_html_e('Read more', 'nextbuild') ?></a>
			    </div><!-- end desc -->
			</div><!-- end blog-wrapper -->
		</div>
	<?php endwhile; wp_reset_postdata(); ?>
</div>
	<?php return ob_get_clean();
}
add_shortcode( 'nextbuild-blog-post', 'nextbuild_blog_post' );


add_action('init', 'nextbuild_blog_post_kc');

function nextbuild_blog_post_kc(){
	if (function_exists('kc_add_map')) {
		kc_add_map(
			array(
				'nextbuild-blog-post'	=>	array(
					'name'	=>	__( 'Blog Post', 'nextbuild' ),
					'icon'	=>	'dashicons dashicons-schedule',
					'category'	=>	'NextBuild',
					'params'	=>	array(
						array(
							'name'	=>	__( 'post_per_page', 'nextbuild' ),
							'label'	=>	__( 'Posts Per Page', 'nextbuild' ),
							'type'	=>	'text',
							'admin_label'	=>	true,
						),
					)
				),
			)
		);
	}
}