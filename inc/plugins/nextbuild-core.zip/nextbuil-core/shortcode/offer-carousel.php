<?php

/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *		Name: Offer Carousel
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */
function nextbuild_offer_carousel( $atts, $content) {
	$atts = shortcode_atts( array(
		'posts_per_page' => '',
	), $atts, 'nextbuild-offer-carousel' );
extract($atts);
ob_start();?>

<div id="owl-sticky" class="row sticky-row">

<?php
	$offers = new WP_Query(array(
		'post_type'	=>	'nextbuild-offer',
		'post_per_pages'	=>	$posts_per_page,
	));
	while ($offers->have_posts()) : $offers->the_post(); ?>

        <div class="sticky-col">
        	<?php if (has_post_thumbnail( )): ?>
            <div class="imageWrapper">
            	<?php the_post_thumbnail( 'nextbuild-post-thumbnail', array('class' => 'img-responsive') ); ?>
            </div>
        	<?php endif; ?>
            <div class="big-meta">
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            </div>
        </div>

    <?php endwhile; ?>
    </div><!-- end row -->

<?php return ob_get_clean(); wp_reset_postdata();

}
add_shortcode( 'nextbuild-offer-carousel', 'nextbuild_offer_carousel' );


add_action( 'init', 'nextbuild_offer_carousel_kc');

function nextbuild_offer_carousel_kc(){

if (function_exists('kc_add_map')) {
	kc_add_map(
		array(
			'nextbuild-offer-carousel'	=>	array(
				'name'	=>	__( 'Offers Carousel', 'nextbuild' ),
				'icon'	=>	'dashicons dashicons-welcome-view-site',
				'category'	=>	'NextBuild',
				'params'	=>	array(
					array(
						'name'	=>	__( 'posts_per_page', 'nextbuild' ),
						'type'	=>	'text',
						'label'	=>	__( 'Posts Per Page', 'nextbuild' ),
						'description'	=>	__( 'Type Here how much post you want to add in your carousel', 'nextbuild' ),
						'admin_label'	=>	true
					),
				)
			),
		)
	);
}

}


