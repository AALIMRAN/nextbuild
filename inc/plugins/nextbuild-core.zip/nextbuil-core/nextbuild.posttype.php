<?php
/**
 * Next Build Post Type
 */
require_once('posttype/project.posttype.php');
require_once('posttype/offer.posttype.php');