<?php

/**
 * Registers a new post type
 * @uses $wp_post_types Inserts new post type object into the list
 *
 * @param string  Post type key, must not exceed 20 characters
 * @param array|string  See optional args description above.
 * @return object|WP_Error the registered post type object, or an error object
 */
function nextbuild_offer_posttype() {

	$labels = array(
		'name'               => __( 'Offers Carousel', 'nextbuild' ),
		'singular_name'      => __( 'Offers', 'nextbuild' ),
		'add_new'            => _x( 'Add New Offers', 'nextbuild', 'nextbuild' ),
		'add_new_item'       => __( 'Add New Offers', 'nextbuild' ),
		'edit_item'          => __( 'Edit Offers', 'nextbuild' ),
		'new_item'           => __( 'New Offers', 'nextbuild' ),
		'view_item'          => __( 'View Offers', 'nextbuild' ),
		'search_items'       => __( 'Search Offers Carousel', 'nextbuild' ),
		'not_found'          => __( 'No Offers Carousel found', 'nextbuild' ),
		'not_found_in_trash' => __( 'No Offers Carousel found in Trash', 'nextbuild' ),
		'parent_item_colon'  => __( 'Parent Offers:', 'nextbuild' ),
		'menu_name'          => __( 'Offers Carousel', 'nextbuild' ),
	);

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'menu_icon'           => 'dashicons-welcome-view-site',
		'supports'            => array(
			'title',
			'editor',
			'thumbnail',
		),
	);

	register_post_type( 'offers', $args );
}

add_action( 'init',  'nextbuild_offer_posttype' );


/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
function nextbuild_offer_taxonomy() {

	$labels = array(
		'name'                  => _x( 'Categories', 'Taxonomy Categories', 'nextbuild' ),
		'singular_name'         => _x( 'Category', 'Taxonomy Category', 'nextbuild' ),
		'search_items'          => __( 'Search Categories', 'nextbuild' ),
		'popular_items'         => __( 'Popular Categories', 'nextbuild' ),
		'all_items'             => __( 'All Categories', 'nextbuild' ),
		'parent_item'           => __( 'Parent Category', 'nextbuild' ),
		'parent_item_colon'     => __( 'Parent Category', 'nextbuild' ),
		'edit_item'             => __( 'Edit Category', 'nextbuild' ),
		'update_item'           => __( 'Update Category', 'nextbuild' ),
		'add_new_item'          => __( 'Add New Category', 'nextbuild' ),
		'new_item_name'         => __( 'New Category Name', 'nextbuild' ),
		'add_or_remove_items'   => __( 'Add or remove Categories', 'nextbuild' ),
		'choose_from_most_used' => __( 'Choose from most used Categories', 'nextbuild' ),
		'menu_name'             => __( 'Categories', 'nextbuild' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'hierarchical'      => true,

	);

	register_taxonomy( 'offers-categories', array( 'offers' ), $args );
}

add_action( 'init', 'nextbuild_offer_taxonomy' );