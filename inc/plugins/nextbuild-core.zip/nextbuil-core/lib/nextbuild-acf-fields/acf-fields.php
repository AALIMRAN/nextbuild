<?php 
if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
	'key' => 'group_5aa72ac0640fc',
	'title' => 'Page',
	'fields' => array(
		array(
			'key' => 'field_5aa72ac6c001e',
			'label' => 'Header On Off',
			'name' => 'header_on_off',
			'type' => 'true_false',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'message' => '',
			'default_value' => 1,
			'ui' => 1,
			'ui_on_text' => 'ON',
			'ui_off_text' => 'OFF',
		),
		array(
			'key' => 'field_5aa72b05c001f',
			'label' => 'Custom Page title',
			'name' => 'custom_page_title',
			'type' => 'text',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => array(
				array(
					array(
						'field' => 'field_5aa72ac6c001e',
						'operator' => '==',
						'value' => '1',
					),
				),
			),
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => 'Page Title',
			'placeholder' => 'Set Page Title',
			'prepend' => '',
			'append' => '',
			'maxlength' => '',
		),
		array(
			'key' => 'field_5aa738a6f4198',
			'label' => 'Page Layout Select',
			'name' => 'page_layout_select',
			'type' => 'select',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'choices' => array(
				'no-sidebar' => 'No Sidebar',
				'left-sidebar' => 'Left Sidebar',
				'right-sidebar' => 'Right Sidebar',
			),
			'default_value' => array(
				0 => 'right-sidebar',
			),
			'allow_null' => 0,
			'multiple' => 0,
			'ui' => 1,
			'ajax' => 1,
			'return_format' => 'value',
			'placeholder' => '',
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'page',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => 1,
	'description' => '',
));

endif;


 ?>